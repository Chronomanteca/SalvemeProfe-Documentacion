export const environment = {
  production: false,
  firebaseApiKey: 'AIzaSyBYrrOGUXFPkfTsKaAz6O2F42XeVTbRvpA',
  dbUrl: 'https://salveme-profe-default-rtdb.firebaseio.com/salveme-profe'
};
