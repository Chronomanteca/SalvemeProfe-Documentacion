export const environment = {
  production: true,
  firebaseApiKey: 'AIzaSyBYrrOGUXFPkfTsKaAz6O2F42XeVTbRvpA'
};
